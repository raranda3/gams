﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Datos;
using Datos.Dao;
using LogicaGams;
using Presentacion.Models;

namespace Presentacion.Controllers
    {
    public class DatosController : Controller
        {
        // GET: Datos
        private DatosGamsImp dao = new DatosGamsImp();
        public ActionResult Index()
            {           
            //Se llama de la base de datos lo que hay almacenado y se muestra en la tabla
            return View(convertirEVM(dao.consultarDatos()));
            }

        // GET: Datos/Details/5
        public ActionResult Details( int id )
            {
            return View();
            }

        // GET: Datos/Create
        public ActionResult Create()
            {

            ProcessGams pg = new ProcessGams();
            ViewBag.sal= pg.procesarArchivo(); //este parametro sal no se usa. es para validar
            return RedirectToAction("Index");
            }

        // POST: Datos/Create
        [HttpPost]
        public ActionResult Create(int i=0)
            {
            try
                {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
                } catch
                {
                return View();
                }
            }

        //Este método se puede cambiar usando Mappers
        public ICollection<DatosViewModel> convertirEVM( ICollection<DatosGams> filas )
            {
            ICollection<DatosViewModel> datosMostrar = new List<DatosViewModel>();
            foreach (DatosGams dg in filas)
                {
                DatosViewModel dvm = new DatosViewModel(dg.indice, dg.valor);
                dvm.idRow = dg.idRow;
                datosMostrar.Add(dvm);
                }
            return datosMostrar;
            }
        }
    }
