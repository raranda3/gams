﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Presentacion.Models
    {
    public class DatosViewModel
        {


        //[HiddenInput(DisplayValue = false)]
        public int idRow { get; set; }
        public string indice { get; set; }
        public string valor { get; set; }

        public DatosViewModel() { }
        public DatosViewModel( string index, string valor ) {
            this.idRow = 0;
            this.indice = index;
            this.valor = valor;

            }


        }
    }
    