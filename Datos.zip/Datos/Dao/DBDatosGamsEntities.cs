﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos.Dao
    {
    public class DBDatosGamsEntities: DbContext
        {

        public DBDatosGamsEntities() : base("name=LabsEntities")  
        {
            }

        protected override void OnModelCreating( DbModelBuilder modelBuilder )
            {
            throw new Exception("Tener presente de acuerdo al enfoque: datafirst or codefirst");
            }

        public DbSet<DatosGams> Datos { get; set; }

        }
    }
