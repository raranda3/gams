﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos.Dao
    {
    public class DatosGamsImp : IDatosGams
        {
        private DBDatosGamsEntities db;
        public DatosGamsImp()
            {
            db = new DBDatosGamsEntities();
            }
        public ICollection<DatosGams> consultarDatos()
            {
            return db.Datos.ToList();
            }

        public string insertarDatos( DatosGams dg )
            {
            string salida = "";
            try
                {
                db.Datos.Add(dg);

                } catch (Exception e)
                {
                salida = e.Message;
               
                 }
            salida = "Se almacenaron correctamente los datos";
            return salida;

            }
        public void GuardarEnBD()
            {
            try
                {
                db.SaveChanges();
                } catch (DbEntityValidationException dbEx)

                // este tramo no es requerido solo se hace para revisar la trzabilidad cuando hay error al insertar
                {
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                    {
                    foreach (var validationError in validationErrors.ValidationErrors)
                        {
                        Trace.TraceInformation("Property: {0} Error: {1}",
                            validationError.PropertyName,
                            validationError.ErrorMessage);
                        }
                    }

                //-------------------------------
                }
            }
        }
    }
